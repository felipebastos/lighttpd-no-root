<?php
    exec ( 'cd ../../ && ./stop.sh' );
?>
