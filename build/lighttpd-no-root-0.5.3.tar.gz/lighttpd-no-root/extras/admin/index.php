<a href="/admin/parar.php">Parar o servidor</a>
<br><br><hr><br><br>
<?php
    phpinfo();
?>
